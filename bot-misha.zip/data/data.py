COUNTRIES = ['uzbekistan']

INTERESTS = ['communication']